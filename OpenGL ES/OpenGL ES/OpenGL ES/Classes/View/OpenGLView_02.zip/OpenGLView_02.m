//
// Created by suger on 2018/2/8.
// Copyright (c) 2018 suger. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "OpenGLView_02.h"
#import "GLESUtils.h"
#import "ksMatrix.h"

@interface OpenGLView_02(){

    ksMatrix4 _modelViewMatrix;
    ksMatrix4 _projectionMatrix;


    float _Xpos;
    float _Ypos;
    float _Zpos;

    float _XRot;
    float _ZScale;

}
- (void)setupLayer;
- (void)setupContext;
- (void)setupRenderBuffer;
- (void)setupFrameBuffer;
- (void)destoryRenderAndFrameBuffer;
- (void)render;
- (void)setupProgram;
- (void)setupProjection;
- (void)updateTransform;
- (void)drawTriCone;

// 设置默认 参数
- (void)_setDefaultValue;

@end

@implementation OpenGLView_02 {

}

- (void)dealloc {
    
    [self destoryRenderAndFrameBuffer];
    
    _glContext = nil;
    
    NSLog(@"%s",__func__);
}

+ (Class)layerClass{
    return CAEAGLLayer.class;
}

- (instancetype)init{
    return nil;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self onCreateResource];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self onCreateResource];
    }

    return self;
}

- (void)onCreateResource {
    
    self.backgroundColor = UIColor.whiteColor;
    [self _setDefaultValue];

    [self setupLayer];
    
    [self setupContext];
    
    [self setupProgram];

    [self setupProjection];
    
    [self doReastBtnAction:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [EAGLContext setCurrentContext:_glContext];
    glUseProgram(_programHandle);

    [self destoryRenderAndFrameBuffer];

    [self setupRenderBuffer];

    [self setupFrameBuffer];

    [self updateTransform];
    
    [self render];
}

#pragma mark - tool
- (void)setupLayer {
    _glLayer = (CAEAGLLayer *) self.layer;
    /*设置为不透明*/
    _glLayer.opaque = YES;

    _glLayer.drawableProperties = @{
            kEAGLDrawablePropertyRetainedBacking : @(NO),
            kEAGLDrawablePropertyColorFormat : kEAGLColorFormatRGBA8
    };
}

- (void)setupContext {
    EAGLRenderingAPI api = kEAGLRenderingAPIOpenGLES2;
    _glContext = [[EAGLContext alloc] initWithAPI:api];

    if (!_glContext){
        NSLog(@"failed to initialize opengles 2.0 context");
        abort();
    }

    if (![EAGLContext setCurrentContext:_glContext]){
        NSLog(@"failed to set context opengl context");
        abort();
    }
}

- (void)setupRenderBuffer {
    glGenRenderbuffers(1, &_colorRenderBuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, _colorRenderBuffer);
    // 为 color renderbuffer 分配存储空间
    [_glContext renderbufferStorage:GL_RENDERBUFFER fromDrawable:_glLayer];
}

- (void)setupFrameBuffer {
    glGenFramebuffers(1, &_frameBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, _frameBuffer);

    /**
     * 将 _colorRenderBuffer 装配到 GL_COLOR_ATTACHMENT0 这个装配点上
     * 该函数是将相关 buffer（三大buffer之一）attach到framebuffer上（如果 renderbuffer不为 0，知道前面为什么说glGenRenderbuffers 返回的id 不会为 0 吧）或从 framebuffer上detach（如果 renderbuffer为 0）。
     * 参数 attachment 是指定 renderbuffer 被装配到那个装配点上，其值是GL_COLOR_ATTACHMENT0, GL_DEPTH_ATTACHMENT, GL_STENCIL_ATTACHMENT中的一个，分别对应 color，depth和 stencil三大buffer。
     */
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                              GL_RENDERBUFFER, _colorRenderBuffer);
}

- (void)destoryRenderAndFrameBuffer {
    glDeleteBuffers(1, &_frameBuffer);
    _frameBuffer = 0;

    glDeleteBuffers(1, &_colorRenderBuffer);
    _colorRenderBuffer = 0;
}

- (void)render {

    if (_glContext == nil)
        return;
    
    glClearColor(0.f, 1.f, 0.f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);

    
    // setup viewport
    glViewport(0, 0, self.frame.size.width, self.frame.size.height);
    

    [self drawTriCone];
    
    
    [_glContext presentRenderbuffer:GL_RENDERBUFFER];
}



- (void)setupProgram {
    // load shaders
    NSString *vertexShaderPath = [[NSBundle mainBundle]pathForResource:@"VertexShader" ofType:@"glsl"];
    NSString *fragmentShaderPath = [[NSBundle mainBundle] pathForResource:@"FragmentShader" ofType:@"glsl"];
    
    _programHandle = [GLESUtils loadProgram:vertexShaderPath
                 withFragmentShaderFilepath:fragmentShaderPath];
    if (_programHandle == 0) {
        NSLog(@" >> Error: Failed to setup program.");
        return;
    }
    
    glUseProgram(_programHandle);

    // get the attribute position slot from program
    //
    _positionSlot = glGetAttribLocation(_programHandle, "vPosition");

    //get the uniform model-view matrix slot from program
    //
    _modelViewSlot = glGetUniformLocation(_programHandle, "modelView");

    //get the uniform projection matrix slot form program
    _projectionSlot = glGetUniformLocation(_programHandle, "projection");

}

- (void)setupProjection {

    /**
     * ksMatrixLoadIdentity 是 GLESMath 中的一个数学函数，用来将指定矩阵重置为单位矩阵，而 ksPerspective 与前文中讲到的 gluPersoective 作用一样。在这里，我们设置视锥体的近裁剪面到观察者的距离为 1， 远裁剪面到观察者的距离为 20，视角为 60度，
     * 然后装载投影矩阵。默认的观察者位置在原点，视线朝向 -Z 方向，因此近裁剪面其实就在 z = -1 这地方，远裁剪面在 z = -20 这地方，z 值不在(-1, -20) 之间的物体是看不到的
     */
    
    // generate a perspective matrix with a 60 degree FOV
    //
    float aspect = self.frame.size.width / self.frame.size.height;
    ksMatrixLoadIdentity(&_projectionMatrix);
    ksPerspective(&_projectionMatrix, 60.f, aspect, 1.f, 20.f);

    //load projection matrix
    glUniformMatrix4fv(_projectionSlot, 1, GL_FALSE, (GLfloat*)&_projectionMatrix.m[0][0]);
}

- (void)updateTransform {

    /**
     ksTranslate，ksRotate，ksScale 也是 GLESMath 中的数学函数，作用与 glTranslate，glRotate，glScale 相同，分别用于平移，绕轴旋绕以及缩放。在这里，设置在 x 方向上平移，平移量将由 self.posX 控制，而这个属性最终是由滑块控制的，从而达到用户移动物体的目的；将 z 设置为 -5.5 (介于 (-1, -20) 之间，前面有讲)；此外还设置绕 x 轴旋绕 0 度，在 x，y，z三个方向上缩放 1 倍，这两个函数的调用是为下一步的旋转和缩放控制准备的。最后，装载模型视图矩阵。
     */
    
    // Generate a model view matrix to rotate/translate/scale
    //
    ksMatrixLoadIdentity(&_modelViewMatrix);
    
    // Translate away from the viewer
    //
    ksMatrixTranslate(&_modelViewMatrix, _Xpos, _Ypos, _Zpos);
    
    // Rotate the triangle
    //
    ksMatrixRotate(&_modelViewMatrix, _XRot, 1.0, 0.0, 0.0);
    
    // Scale the triangle
    ksMatrixScale(&_modelViewMatrix, 1.0, 1.0, _ZScale);
    
    // Load the model-view matrix
    glUniformMatrix4fv(_modelViewSlot, 1, GL_FALSE, (GLfloat*)&_modelViewMatrix.m[0][0]);

}


- (void)drawTriCone {
    
    GLfloat vertices[] = {
        0.7f,  0.7f,  0.0f,
        0.7f, -0.7f,  0.0f,
       -0.7f, -0.7f,  0.0f,
       -0.7f,  0.7f,  0.0f,
        0.0f,  0.0f, -1.0f,
    };
    
    GLubyte indices[] = {
       0, 1, 1, 2, 2, 3, 3, 0,
       4, 0, 4, 1, 4, 2, 4, 3,
    };
    
    
    glVertexAttribPointer(_positionSlot, 3, GL_FLOAT, GL_FALSE, 0, vertices);
    glEnableVertexAttribArray(_positionSlot);
    
    // draw lines
    /**
     这次我们使用顶点索引数组结合 glDrawElements 来渲染，而在 Tutorial02 中，使用的是 glDrawArrays。使用顶点索引数组有什么好处呢？很明显，我们可以减少存储重复顶点的内存消耗。比如在本例的索引表中，我们重复利用了顶点 0，1，2，3，4，它们对应 vertices 数组中5个顶点（三个浮点数组成一个顶点）。
     
     第一个参数 mode 为描绘图元的模式，其有效值为：GL_POINTS, GL_LINES, GL_LINE_STRIP,  GL_LINE_LOOP,  GL_TRIANGLES,  GL_TRIANGLE_STRIP, GL_TRIANGLE_FAN。这些模式具体含义下面有介绍。
     
     第二个参数 count 为顶点索引的个数也就是，type 是指顶点索引的数据类型，因为索引始终是正值，索引这里必须是无符号型的非浮点类型，因此只能是 GL_UNSIGNED_BYTE, GL_UNSIGNED_SHORT, GL_UNSIGNED_INT 之一，为了减少内存的消耗，尽量使用最小规格的类型如 GL_UNSIGNED_BYTE。
     
     第三个参数 indices 是存放顶点索引的数组。（indices 是 index 的复数形式，3D 里面很多单词的复数都挺特别的。）
     */
    glDrawElements(GL_LINES, sizeof(indices)/sizeof(GLubyte), GL_UNSIGNED_BYTE, indices);
}



#pragma mark - GL02TutorialViewProtocol

- (void)doXposValueChanged:(CGFloat)value {

    NSLog(@"%s %.2f",__func__,value);
    _Xpos = value;
    [self updateTransform];
    
    [self render];
}

- (void)doYposValueChanged:(CGFloat)value {

    NSLog(@"%s %.2f",__func__,value);
    _Ypos = value;
    [self updateTransform];
    
    [self render];
}

- (void)doZposValueChanged:(CGFloat)value {

    NSLog(@"%s %.2f",__func__,value);
    _Zpos = value;
    [self updateTransform];
    
    [self render];
}

- (void)doXrotateValueChanged:(CGFloat)value {

    NSLog(@"%s %.2f",__func__,value);
    _XRot = value;
    [self updateTransform];
    
    [self render];
}

- (void)doZscaleValueChanged:(CGFloat)value {

    NSLog(@"%s %.2f",__func__,value);
    _ZScale = value;
    [self updateTransform];
    
    [self render];
}

- (void)doAutoBtnAction:(UIButton *)button {
    
}

- (void)doReastBtnAction:(UIButton *)button {

    [self _setDefaultValue];
    [self updateTransform];
    [self render];
}


#pragma mark - private
- (void)_setDefaultValue {
    _Xpos = 0.f;
    _Ypos = 0.f;
    _Zpos = -5.5f;

    _ZScale = 1.f;
    _XRot = 0.f;
}

@end



